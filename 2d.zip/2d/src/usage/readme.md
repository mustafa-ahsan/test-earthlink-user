## Godot Sharp Some - Examples

Animated examples of drawing Api extensions.  
\
![pic](./../../doc/images/dots_and_lines_animation.gif)  
![pic](./../../doc/images/connections_animation.gif)  
![pic](./../../doc/images/candlesticks_animation.gif)  
![pic](./../../doc/images/primitives_animation.gif)  
